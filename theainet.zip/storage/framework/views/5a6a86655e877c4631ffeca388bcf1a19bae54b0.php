<?php $__env->startSection('content'); ?>
<div class="all-title-box">
    <div class="container text-center">
        <h1 class="tai-mt-0">EXPRESSION OF INTEREST<span class="m_1"></span></h1>
    </div>
</div>
<div id="overviews" class="section lb w3-white">
    <div class="container">
        <div class="section-title row">
            <div class="col-md-6 offset-md-3">

                <?php if(session('status') && session('status') === "success"): ?>
                    <div class="card w3-border-orange">
                        <div class="card-header w3-orange w3-border-orange"><?php echo e(__('EXPRESSION OF INTEREST FORM')); ?></div>
                        <div class="card-body">
                                Thank you for your interest! We may contact you for more details, if necessary. Further information will be sent to short-listed participants very soon
                                <br/><a type="button" class="btn w3-orange" href="/">Go To Home</a>
                        </div>

                    </div>
                <?php else: ?>
                    <div class="card w3-border-orange">
                        <div class="card-header w3-orange w3-border-orange"><?php echo e(__('EXPRESSION OF INTEREST FORM')); ?></div>
                        <div class="card-body">
                            <form action="/announcementtwo" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" name="name" id="name" class="form-control"
                                        placeholder="Enter Your Name">
                                </div>
                                <div class="form-group">
                                    <label for="name_of_institution">Name On Institution With Address</label>
                                    <textarea name="name_of_institution" id="name_of_institution" class="form-control"
                                        placeholder="Enter Your Name Of Institution With Address"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="classes">Select Classes You Teach</label>
                                    <select name="classes" id="classes" class="form-control">
                                        <option value="5-8">5-8</option>
                                        <option value="9-10">9-10</option>
                                        <option value="11-12">11-12</option>
                                        <option value="Sr. College">Sr. College</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="qualification">Qualification</label>
                                    <input type="text" name="qualification" id="qualification" class="form-control"
                                        placeholder="Enter Your Qualification">
                                </div>
                                <div class="form-group">
                                    <label for="teaching_experience">Select Teaching Experience</label>
                                    <select class="form-control" name="teaching_experience" id="teaching_experience">
                                        <option>1-3 Yrs</option>
                                        <option>4-10 Yrs</option>
                                        <option>11-20 Yrs</option>
                                        <option>>21 Years</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" name="email" id="email"
                                        placeholder="Enter Your Email">
                                </div>
                                <hr>
                                <div class="form-group">
                                    <label for="mobile_no">Mobile No</label>
                                    <input type="text" class="form-control" name="mobile_no" id="mobile_no"
                                        placeholder="Enter Your Mobile No">
                                </div>
                                <div class="form-group">
                                    <label for="whatsapp_no">WhatsApp No (If other then the above no)</label>
                                    <input type="text" class="form-control" name="whatsapp_no" id="whatsapp_no"
                                        placeholder="Enter WhatsApp No">
                                </div>
                                <div class="form-group">
                                    <label for="twitter_handle">Twitter Handle</label>
                                    <input type="text" class="form-control" name="twitter_handle" id="twitter_handle"
                                        placeholder="Enter Your Twitter Handle">
                                </div>
                                <hr>
                                <div class="form-group">
                                    <label for="que_one">Have you participated in any of the AINET initiatives? Please share
                                        brief details like name of event, year, your presentation/participation
                                        details.</label>
                                    <textarea class="form-control" name="que_one" id="que_one" rows="3"
                                        placeholder="Enter Your Answer Here"></textarea>
                                </div>
                                <hr>
                                <div class="form-group">
                                    <label for="que_two">How do you think you may contribute to this project?</label>
                                    <input type="text" class="form-control" name="que_two" id="que_two"
                                        placeholder="Enter Your Answer Here">
                                </div>
                                <hr>
                                <div class="form-group">
                                    <label for="que_three">What responsibilities would you like to shoulder during the
                                        project?</label>
                                    <input type="text" class="form-control" name="que_three" id="que_three"
                                        placeholder="Enter Your Answer">
                                </div>
                                <hr>
                                <div class="form-group">
                                    <label for="que_four">How much time would you be able to give to this project per
                                        week?</label>
                                    <input type="text" class="form-control" name="que_four" id="que_four"
                                        placeholder="Enter Your Answer">
                                </div>
                                <div class="form-group">
                                    <label for="que_five">What are your strengths as a teacher/trainer/facilitator?</label>
                                    <input type="text" class="form-control" name="que_five" id="que_five"
                                        placeholder="Enter Your Answer">
                                </div>
                                <hr>
                                <div class="form-group">
                                    <label for="que_six">What challenges you anticipate during the project?</label>
                                    <input type="text" class="form-control" name="que_six" id="que_six"
                                        placeholder="Enter Your Answer">
                                </div>
                                <div class="form-group">
                                    <label for="que_seven">Are you a member of any teacher network or association? Give
                                        details about your role and responsibilities in your association.</label>
                                    <textarea class="form-control" name="que_seven" id="que_seven" rows="3"
                                        placeholder="Enter Your Answer"></textarea>
                                </div>
                                <hr>
                                <div class="form-group">
                                    <label for="que_eight">As the name suggests, the project is technology driven and the
                                        participant teachers will get an opportunity to hone their skills in using
                                        technology for managing teacher associations, online collaboration and networking.
                                        The project requires basic knowledge social media. Tick your level of awareness
                                        about social media platforms like Facebook and Twitter
                                    </label>
                                    <select class="form-control" name="que_eight" id="que_eight">
                                        <option>Expert</option>
                                        <option>Active User</option>
                                        <option>Novice</option>
                                    </select>
                                </div>
                                <hr>
                                From the following online activities, mark the activities that you have done.
                                <hr>
                                <b>Webinar</b><br>
                                <div class="form-check row">
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_a" id="que_nine_a"
                                            value="Never" checked> Never
                                    </label>
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_a" id="que_nine_a"
                                            value="Participated"> Participated
                                    </label>
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_a" id="que_nine_a"
                                            value="Hosted"> Hosted
                                    </label>
                                </div>
                                <hr>
                                <b>Zoom Meeting</b><br>
                                <div class="form-check row">
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_b" id="que_nine_b"
                                            value="Never" checked> Never
                                    </label>
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_b" id="que_nine_b"
                                            value="Participated"> Participated
                                    </label>
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_b" id="que_nine_b"
                                            value="Hosted"> Hosted
                                    </label>
                                </div>
                                <hr>
                                <b>Online Conference</b><br>
                                <div class="form-check row">
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_c" id="que_nine_c"
                                            value="Never" checked> Never
                                    </label>
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_c" id="que_nine_c"
                                            value="Participated"> Participated
                                    </label>
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_c" id="que_nine_c"
                                            value="Hosted"> Hosted
                                    </label>
                                </div>
                                <hr>
                                <b>Virtual Field Trip</b><br>
                                <div class="form-check row">
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_d" id="que_nine_d"
                                            value="Never" checked> Never
                                    </label>
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_d" id="que_nine_d"
                                            value="Participated"> Participated
                                    </label>
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_d" id="que_nine_d"
                                            value="Hosted"> Hosted
                                    </label>
                                </div>
                                <hr>
                                <b>Facebook Live</b><br>
                                <div class="form-check row">
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_e" id="que_nine_e"
                                            value="Never" checked> Never
                                    </label>
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_e" id="que_nine_e"
                                            value="Participated"> Participated
                                    </label>
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_e" id="que_nine_e"
                                            value="Hosted"> Hosted
                                    </label>
                                </div>

                                <hr>
                                <b>YouTube Live Streaming</b><br>
                                <div class="form-check row">
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_f" id="que_nine_f"
                                            value="Never" checked> Never
                                    </label>
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_f" id="que_nine_f"
                                            value="Participated"> Participated
                                    </label>
                                    <label class="form-check-label col-sm-3">
                                        <input class="form-check-input" type="radio" name="que_nine_f" id="que_nine_f"
                                            value="Hosted"> Hosted
                                    </label>
                                </div>
                                <hr>
                                <div class="form-group">
                                <label for="que_ten">Any other information you would like to share with us?</label>
                                <textarea class="form-control" name="que_ten" id="que_ten" rows="3" placeholder="Enter Your Answer"></textarea>
                                </div>
                                <button type="submit" name="" id="" class="btn w3-orange btn-lg btn-block">Submit</button>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>


            </div><!-- end messagebox -->
        </div><!-- end col -->

        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
            <div class="post-media wow fadeIn">
                <!-- <img src="images/q1.jpg" alt="" class="img-fluid img-rounded"> -->
            </div><!-- end media -->
        </div><!-- end col -->
    </div>
</div><!-- end messagebox -->
</div><!-- end col -->

</div><!-- end row -->
</div><!-- end container -->
<!-- </div>end section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/theainet/resources/views/announcementtwo.blade.php ENDPATH**/ ?>