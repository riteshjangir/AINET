<?php $__env->startSection('content'); ?>
    
    <!-- ***** Breadcrumb Area Start ***** -->
    <div class="breadcrumb-area">
        <div class="container h-100">
            <div class="row h-100 align-items-end">
                <div class="col-12">
                    <div class="breadcumb--con">
                        <h2 class="title">About
                        </h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">About
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <!-- Background Curve -->
        <div class="breadcrumb-bg-curve">
            <img src="./img/core-img/curve-5.png" alt="">
        </div>
    </div>
    <!-- ***** Breadcrumb Area End ***** -->

    <!-- ***** Services Area Start ***** -->
    <section class="uza-services-area section-padding-80-0">
        <div class="container">
            <div class="row">

                <!-- Single Service Area -->
                <div class="col-12">
                    <div class="single-service-area mb-80">
                        <!-- Service Icon -->
                        
                        <h2>What Is AINET?</h2>
                        <p align=" justify">AINET is an online pan-india community of people interested in the teaching and learning of english in india – teachers, trainers, teacher educators, publishers, policy makers, educational authorities, researchers, students, private tutors and free-lancers. We welcome anyone who wishes to promote the growth of the teachers and learners of english, including their own, to be a part of this community. AINET is an associate of the international association of teachers of english as a foreign language (iatefl), uk. &nbsp; <a href="/new_about" class="read-more-btn"> Read More <i class="arrow_carrot-2right"></i></a>
                        </p>

                    </div>
                </div>


            </div>
        </div>
    </section>
    <!DOCTYPE html>
    <html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    html {
      box-sizing: border-box;
    }
    
    *, *:before, *:after {
      box-sizing: inherit;
    }
    
    .column {
      float: left;
      width: 33.3%;
      margin-bottom: 16px;
      padding: 0 8px;
    }
    
    @media  screen and (max-width: 650px) {
      .column {
        width: 100%;
        display: block;
      }
    }
    
    .card {
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    }
    
    .container {
      padding: 0 16px;
    }
    
    .container::after, .row::after {
      content: "";
      clear: both;
      display: table;
    }
    
    .title {
      color: grey;
    }
    
    .button {
      border: none;
      outline: 0;
      display: inline-block;
      padding: 8px;
      color: white;
      background-color: #000;
      text-align: center;
      cursor: pointer;
      width: 100%;
    }
    
    .button:hover {
      background-color: #555;
    }
    </style>
    </head>
    <body>
    
    <h2 align="center">Our Team</h2>
    <br>
    
    <div class="row">
    <div class="container h-100">

      <div class="column">
        <div class="card">
          <img src="/images/Amol Sir 2.jpg" alt="Jane" style="width:100%">
          <div class="container">
            <h2>Amol Padwad</h2>
            <p class="title">Founder</p>
            
          </div>
        </div>
      </div>
    
      <div class="column">
        <div class="card">
          <img src="/images/Nadeem Khan 2.jpg" alt="Mike" style="width:100%">
          <div class="container">
            <h2>Nadeem Khan</h2>
            <p class="title">Treasure</p>
            
          </div>
        </div>
      </div>
    </div>
    </div>
    

    //
    <h2 align="center">AINET IN NEWS</h2>
    <br>
    
    <div class="row">
    <div class="container h-100">

      <div class="column">
        <div class="card">
          <img src="/images/Poster1.jpg" alt="Jane" style="width:100%">
          <div class="container">
            <h2>Event 1</h2>
            <p class="title">Founder</p>
            <p>Some text that describes me lorem ipsum ipsum lorem.</p>
            <p>example@example.com</p>
            <p><button class="button">Read More</button></p>
          </div>
        </div>
      </div>
    
      <div class="column">
        <div class="card">
          <img src="/images/Poster2.jpg" alt="Mike" style="width:100%">
          <div class="container">
            <h2>Event 2</h2>
            <p class="title">Treasure</p>
            <p>Some text that describes me lorem ipsum ipsum lorem.</p>
            <p>example@example.com</p>
            <p><button class="button">Read More</button></p>
          </div>
        </div>
      </div>
    </div>
    </div>
       <!-- ***** Services Area Start ***** -->
       <section class="uza-services-area section-padding-80-0">
            <div class="container">
                <div class="row">
    
                    <!-- Single Service Area -->
                    <div class="col-12">
                        <div class="single-service-area mb-80">
                            <!-- Service Icon -->
                            
                            <h2>Our Policy</h2>
                            <p align=" justify">AINET is an online pan-india community of people interested in the teaching and learning of english in india – teachers, trainers, teacher educators, publishers, policy makers, educational authorities, researchers, students, private tutors and free-lancers. We welcome anyone who wishes to promote the growth of the teachers and learners of english, including their own, to be a part of this community. AINET is an associate of the international association of teachers of english as a foreign language (iatefl), uk. &nbsp; <a href="/new_about" class="read-more-btn"> Read More <i class="arrow_carrot-2right"></i></a>
                            </p>
    
                        </div>
                    </div>
    
    
                </div>
            </div>
        </section>
     
    
    </body>
    </html>
    
            
    <?php $__env->stopSection(); ?>

   
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\PleskVhosts\theainet.net\newainet\resources\views/about2.blade.php ENDPATH**/ ?>