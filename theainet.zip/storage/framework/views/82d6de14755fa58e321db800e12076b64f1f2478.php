<?php $__env->startSection('content'); ?>
<div class="all-title-box">
    <div class="container text-center">
        <h1 class="tai-mt-0">AINET Ocassional Papers<span class="m_1"></span></h1>
    </div>
</div>
<div id="overviews" class="section lb">
    <div class="container">
        <div class="section-title row text-center">
            <div class="col-md-8 offset-md-2">
                <h3>AINET CONFERENCES</h3>
                <h2>ISSN 2393-8439 (Online) / 2393-8668 (Print)</h2>
                <p>A series of papers containing research studies, factual analyses, theoretical arguments and policy/
                    programme proposals aimed at stimulating and contributing to debates and discussions on English
                    language education in India</p>
                <br>
                <br>
                <h3>AINET OP No. 1/ 2014</h3>
                <a href="http://theainet.net/wp-content/uploads/2017/10/AINET-OP-1-Martin-Wedell-ITE-Curriculum.pdf">
                    <b>Martin Wedell</b>-<i>Initial English Teacher Education and English Curriculum Goals: Bridging the
                        Gap</i></a>
                <br>
                <br>
                <h3>AINET OP No. 2/ 2016</h3>
                <a href="http://theainet.net/wp-content/uploads/2017/10/AINET-OP-1-Martin-Wedell-ITE-Curriculum.pdf">
                    <b>Krishna Dixit</b>-<i>Teacher Motivation: A Conceptual Overview</i></a>
                <!-- <div class="row align-items-center">
    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
        <div class="message-box">
            <h4 class="footer-center1" >UPDATES</h4> -->
                <!-- <ul>
                    <a href="#"><li> Recent Publications – AINET Occasional Paper 2 (Teacher Motivation – A Conceptual Overview); Exploring Learners and Learning of English (2017 Conf Selections)</li></a>

                </ul> -->

                <!-- <h2>WHAT IS AINET?</h2> -->

                <!-- <p>AINET is an online pan-India community of people interested in the teaching and learning of English in India – teachers, trainers, teacher educators, publishers, policy makers, educational authorities, researchers, students, private tutors and free-lancers.</p>
            <p>We welcome anyone who wishes to promote the growth of the teachers and learners of English, including their own, to be a part of this community.</p>
            <p>AINET is an associate of the International Association of Teachers of English as a Foreign Language (IATEFL), UK. AINET evolved out of a Hornby Alumni Project undertaken by Dr. Amol Padwad (amolpadwad@gmail.com) and Krishna Dixit (krishnakdixit@gmail.com).</p> -->


                <!-- <p> Integer rutrum ligula eu dignissim laoreet. Pellentesque venenatis nibh sed tellus faucibus bibendum. Sed fermentum est vitae rhoncus molestie. Cum sociis natoque penatibus et magnis montes, nascetur ridiculus mus. Sed vitae rutrum neque. </p> -->

                <!-- <a href="#" class="hover-btn-new orange"><span>Learn</span></a> -->
            </div><!-- end messagebox -->
        </div><!-- end col -->

        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
            <div class="post-media wow fadeIn">
                <!-- <img src="images/q1.jpg" alt="" class="img-fluid img-rounded"> -->
            </div><!-- end media -->
        </div><!-- end col -->
    </div>


    <!-- <div class="row align-items-center">
    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
        <div class="post-media wow fadeIn">
            <img src="images/q2.jpg" alt="" class="img-fluid img-rounded">
        </div>end media
    </div>end col
    
    < <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
        <div class="message-box">
            <h2>WHY AINET?</h2>
            <p> AINET offers an effective avenue for professional networking and growth for a geographically vast and diverse country like India with the advantage of high speed at low costs.</p>

            <p> AINET brings you resources, information, support and professional networking, which will enable you to grow and to take your career/ interest to greater height and depth.</p> -->

    <!-- <a href="#" class="hover-btn-new orange"><span>Learn More</span></a> -->
</div><!-- end messagebox -->
</div><!-- end col -->

</div><!-- end row -->
</div><!-- end container -->
<!-- </div>end section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/theainet/resources/views/publicationone.blade.php ENDPATH**/ ?>