<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>


    <!-- ***** Welcome Area Start ***** -->
    <section class="welcome-area">
        <div class="welcome-slides owl-carousel">

            <!-- Single Welcome Slide -->
            <div class="single-welcome-slide">
                <!-- Background Curve -->
                <div class="background-curve">
                    <img src="./img/core-img/curve-1.png" alt="">
                </div>

                
                <!-- Welcome Content -->
                
                <div class="welcome-content h-100">
                      
                    
                    <div class="container h-100">
                        
                        <div class="row h-100 align-items-center">
                            <!-- Welcome Text -->
                            <div class="col-12 col-md-6">
                                <div class="welcome-text">
                                        <h1 style="color:#9900FF;">Join a vibrant community of teachers, trainers, teacher educators and researchers!
                                            </h1><br>
                                            <h1 style="color:#0000FF;">Develop. Together.
                                                </h1>
                                        
                                </div>
                            </div>
                            <!-- Welcome Thumbnail -->
                            <div class="col-12 col-md-6">
                                <div class="welcome-thumbnail">
                                    <img src="/images/l1.gif" alt="" data-animation="slideInTop" data-delay="100ms">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            

           
        </div>
    </section>

<!-- <div class=" ">
    <div class="single-footer-widget mb-80"> -->
        <!-- Widget Title -->
                <!-- <div class="section-heading text-center">
                    <h4>Become&nbsp;&nbsp;&nbsp; A &nbsp;&nbsp;Member </h4>
                    <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;S&nbsp;&nbsp;I &nbsp;&nbsp;G&nbsp;&nbsp; N&nbsp;&nbsp; U&nbsp;&nbsp; P&nbsp;&nbsp;</h4>
   
    </div>
</div> -->
<div class="container-fluid text-center">
    <!-- Control the column width, and how they should appear on different devices -->

    <div class="text-join"> 
        <font style="background-color:#DF068C; font-size: 40px; padding: 20px 0px 20px 0px;" color="white">
          <a class="text-join" href="#"><b>Member Login</b></a> 
        </font>
      </div>

    </div>

     <!-- <div class="row">
      <div class="col-sm-1.5" style="background-color:black;"><font color="white">L&nbsp;&nbsp;&nbsp;O&nbsp;&nbsp;&nbsp;G&nbsp;&nbsp;&nbsp;&nbsp;I&nbsp;&nbsp;N</font></div>

    </div> -->
    <!-- ***** Welcome Area End ***** -->
<br/><br/>
  
                  <hr>

<div class="col-12">
                    <div class="single-footer-widget mb-80">
                        <!-- Widget Title -->
                                <div class="section-heading text-center">
                                    <h2>Follow us</h2><br>
                        <div class="footer-social-info">
                            <a href="https://www.facebook.com/ainetindia/" class="facebook" data-toggle="tooltip" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a>fb.com/ainetindia
                            <a href="https://twitter.com/ainetindia" class="twitter" data-toggle="tooltip" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a>@ainetindia
                            
                            <a href="https://www.instagram.com/ainet_india/" class="instagram" data-toggle="tooltip" data-placement="top" title="Instagram"><i class="fa fa-instagram"></i></a>ainet_india
                            <a href="https://www.youtube.com/channel/UCHaFX92EaJzFL7m7fPD591A" class="youtube" data-toggle="tooltip" data-placement="top" title="YouTube"><i class="fa fa-youtube-play"></i></a>AINET India
                            <a href="#" class="rssfeed" data-toggle="tooltip" data-placement="top" title="RSSFeed"><i class="fa fa-rss"></i></a>AINET_RSSFeed

                        </div>
                    </div>
                </div>
    <!-- ***** About Us Area Start ***** -->
    <section class="uza-about-us-area">
        <div class="container">
            <div class="row align-items-center">

                <!-- About Thumbnail -->
                <div class="col-12 col-md-6">
                    <div class="about-us-thumbnail mb-80">
                        
                        <!-- Video Area -->
                        
                    </div>
                </div>

                <!-- About Us Content -->
                <div class="col-12 col-md-6">
                    <div class="about-us-content mb-80">
                        <h2>
                                
                        
                        

                    </div>
                </div>
            </div>
        </div>

        <!-- About Background Pattern -->
        
    <!-- ***** About Us Area End ***** -->

    

    <!-- ***** Portfolio Area Start ***** -->
    <section class="uza-portfolio-area section-padding-80">
        <div class="container">
            <div class="row">
                <!-- Section Heading -->
                <div class="col-12">
                    <div class="section-heading text-center">
                        <h2>Events Highlighted</h2>
                        
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <!-- Portfolio Slides -->
                <div class="portfolio-sildes owl-carousel">

                    <!-- Single Portfolio Slide -->
                    <div class="single-portfolio-slide">
                        <img src="./img/bg-img/3.jpg" alt="">
                        <!-- Overlay Effect -->
                        <div class="overlay-effect">
                            <h4>Digital Marketing</h4>
                            <p>At vero eos et accusam et justo duo dolores et ea rebum. Stet gubergren no sea takimata sanctus est</p>
                        </div>
                        <!-- View More -->
                        <div class="view-more-btn">
                            <a href="#"><i class="arrow_right"></i></a>
                        </div>
                    </div>

                    <!-- Single Portfolio Slide -->
                    <div class="single-portfolio-slide">
                        <img src="./img/bg-img/4.jpg" alt="">
                        <!-- Overlay Effect -->
                        <div class="overlay-effect">
                            <h4>Digital Marketing</h4>
                            <p>At vero eos et accusam et justo duo dolores et ea rebum. Stet gubergren no sea takimata sanctus est</p>
                        </div>
                        <!-- View More -->
                        <div class="view-more-btn">
                            <a href="#"><i class="arrow_right"></i></a>
                        </div>
                    </div>

                    <!-- Single Portfolio Slide -->
                    <div class="single-portfolio-slide">
                        <img src="./img/bg-img/5.jpg" alt="">
                        <!-- Overlay Effect -->
                        <div class="overlay-effect">
                            <h4>Digital Marketing</h4>
                            <p>At vero eos et accusam et justo duo dolores et ea rebum. Stet gubergren no sea takimata sanctus est</p>
                        </div>
                        <!-- View More -->
                        <div class="view-more-btn">
                            <a href="#"><i class="arrow_right"></i></a>
                        </div>
                    </div>

                    <!-- Single Portfolio Slide -->
                    <div class="single-portfolio-slide">
                        <img src="./img/bg-img/6.jpg" alt="">
                        <!-- Overlay Effect -->
                        <div class="overlay-effect">
                            <h4>Digital Marketing</h4>
                            <p>At vero eos et accusam et justo duo dolores et ea rebum. Stet gubergren no sea takimata sanctus est</p>
                        </div>
                        <!-- View More -->
                        <div class="view-more-btn">
                            <a href="#"><i class="arrow_right"></i></a>
                        </div>
                    </div>

                    <!-- Single Portfolio Slide -->
                    <div class="single-portfolio-slide">
                        <img src="./img/bg-img/5.jpg" alt="">
                        <!-- Overlay Effect -->
                        <div class="overlay-effect">
                            <h4>Digital Marketing</h4>
                            <p>At vero eos et accusam et justo duo dolores et ea rebum. Stet gubergren no sea takimata sanctus est</p>
                        </div>
                        <!-- View More -->
                        <div class="view-more-btn">
                            <a href="#"><i class="arrow_right"></i></a>
                        </div>
                    </div>

                    <!-- Single Portfolio Slide -->
                    <div class="single-portfolio-slide">
                        <img src="./img/bg-img/6.jpg" alt="">
                        <!-- Overlay Effect -->
                        <div class="overlay-effect">
                            <h4>Digital Marketing</h4>
                            <p>At vero eos et accusam et justo duo dolores et ea rebum. Stet gubergren no sea takimata sanctus est</p>
                        </div>
                        <!-- View More -->
                        <div class="view-more-btn">
                            <a href="#"><i class="arrow_right"></i></a>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- Client Feedback Area Start -->
        <div class="clients-feedback-area mt-80 section-padding-80 clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <!-- Testimonial Slides -->
                        <div class="testimonial-slides owl-carousel">

                            <!-- Single Testimonial Slide -->
                            <div class="single-testimonial-slide d-flex align-items-center">
                                <!-- Testimonial Thumbnail -->
                                <div class="testimonial-thumbnail">
                                    <img src="./img/bg-img/7.jpg" alt="">
                                </div>
                                <!-- Testimonial Content -->
                                <div class="testimonial-content">
                                    <h4>“Colorlib Ltd’s ranking has gone up so much from the great work that your team has done and our brand get organic sales consistently from your efforts. We are happy that the results of your efforts were lasting and profitable.”</h4>
                                    <!-- Ratings -->
                                    <div class="ratings">
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                    </div>
                                    <!-- Author Info -->
                                    <div class="author-info">
                                        <h5>Prashant Mugale <span>- </span></h5>
                                    </div>
                                    <!-- Quote Icon -->
                                    <div class="quote-icon"><img src="img/core-img/quote.png" alt=""></div>
                                </div>
                            </div>

                            <!-- Single Testimonial Slide -->
                            <div class="single-testimonial-slide d-flex align-items-center">
                                <!-- Testimonial Thumbnail -->
                                <div class="testimonial-thumbnail">
                                    <img src="./img/bg-img/23.jpg" alt="">
                                </div>
                                <!-- Testimonial Content -->
                                <div class="testimonial-content">
                                    <h4>“Colorlib Ltd’s ranking has gone up so much from the great work that your team has done and our brand get organic sales consistently from your efforts. We are happy that the results of your efforts were lasting and profitable.”</h4>
                                    <!-- Ratings -->
                                    <div class="ratings">
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                    </div>
                                    <!-- Author Info -->
                                    <div class="author-info">
                                        <h5>Vikram Adsul <span></span></h5>
                                    </div>
                                    <!-- Quote Icon -->
                                    <div class="quote-icon"><img src="img/core-img/quote.png" alt=""></div>
                                </div>
                            </div>
                            <!-- Single Testimonial Slide -->
                            <div class="single-testimonial-slide d-flex align-items-center">
                                    <!-- Testimonial Thumbnail -->
                                    <div class="testimonial-thumbnail">
                                        <img src="./img/bg-img/23.jpg" alt="">
                                    </div>
                                    <!-- Testimonial Content -->
                                    <div class="testimonial-content">
                                        <h4>“Colorlib Ltd’s ranking has gone up so much from the great work that your team has done and our brand get organic sales consistently from your efforts. We are happy that the results of your efforts were lasting and profitable.”</h4>
                                        <!-- Ratings -->
                                        <div class="ratings">
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                        </div>
                                        <!-- Author Info -->
                                        <div class="author-info">
                                            <h5>Rohini Sankpal <span></span></h5>
                                        </div>
                                        <!-- Quote Icon -->
                                        <div class="quote-icon"><img src="img/core-img/quote.png" alt=""></div>
                                    </div>
                                </div>
                                <!-- Single Testimonial Slide -->
                            <div class="single-testimonial-slide d-flex align-items-center">
                                    <!-- Testimonial Thumbnail -->
                                    <div class="testimonial-thumbnail">
                                        <img src="./img/bg-img/23.jpg" alt="">
                                    </div>
                                    <!-- Testimonial Content -->
                                    <div class="testimonial-content">
                                        <h4>“Colorlib Ltd’s ranking has gone up so much from the great work that your team has done and our brand get organic sales consistently from your efforts. We are happy that the results of your efforts were lasting and profitable.”</h4>
                                        <!-- Ratings -->
                                        <div class="ratings">
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                        </div>
                                        <!-- Author Info -->
                                        <div class="author-info">
                                            <h5>Akanksha Saxena <span></span></h5>
                                        </div>
                                        <!-- Quote Icon -->
                                        <div class="quote-icon"><img src="img/core-img/quote.png" alt=""></div>
                                    </div>
                                </div>
                                <!-- Single Testimonial Slide -->
                            <div class="single-testimonial-slide d-flex align-items-center">
                                    <!-- Testimonial Thumbnail -->
                                    <div class="testimonial-thumbnail">
                                        <img src="./img/bg-img/23.jpg" alt="">
                                    </div>
                                    <!-- Testimonial Content -->
                                    <div class="testimonial-content">
                                        <h4>“Colorlib Ltd’s ranking has gone up so much from the great work that your team has done and our brand get organic sales consistently from your efforts. We are happy that the results of your efforts were lasting and profitable.”</h4>
                                        <!-- Ratings -->
                                        <div class="ratings">
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                        </div>
                                        <!-- Author Info -->
                                        <div class="author-info">
                                            <h5>Darshana Bapat <span></span></h5>
                                        </div>
                                        <!-- Quote Icon -->
                                        <div class="quote-icon"><img src="img/core-img/quote.png" alt=""></div>
                                    </div>
                                </div>

                            <!-- Single Testimonial Slide -->
                            <div class="single-testimonial-slide d-flex align-items-center">
                                <!-- Testimonial Thumbnail -->
                                <div class="testimonial-thumbnail">
                                    <img src="./img/bg-img/24.jpg" alt="">
                                </div>
                                <!-- Testimonial Content -->
                                <div class="testimonial-content">
                                    <h4>“Colorlib Ltd’s ranking has gone up so much from the great work that your team has done and our brand get organic sales consistently from your efforts. We are happy that the results of your efforts were lasting and profitable.”</h4>
                                    <!-- Ratings -->
                                    <div class="ratings">
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                    </div>
                                    <!-- Author Info -->
                                    <div class="author-info">
                                        <h5>Sadeqa Gazal <span></span></h5>
                                    </div>
                                    <!-- Quote Icon -->
                                    <div class="quote-icon"><img src="img/core-img/quote.png" alt=""></div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Client Feedback Area End -->
         <!-- ***** Portfolio Area Start ***** -->
    <section class="uza-portfolio-area section-padding-80">
            <div class="container">
                <div class="row">
                    <!-- Section Heading -->
                    <div class="col-12">
                        <div class="section-heading text-center">
                            
                            
                        </div>
                    </div>
                </div>
            </div>
    
            <div class="container-fluid">
                <div class="row">
                    <!-- Portfolio Slides -->
                    <div class="portfolio-sildes owl-carousel">
    
                        <!-- Single Portfolio Slide -->
                        <div class="single-portfolio-slide">
                            <img src="/images/s3.jpg" alt="">
                            <!-- Overlay Effect -->
                            <div class="overlay-effect">
                                
                                
                            </div>
                            <!-- View More -->
                            <div class="view-more-btn">
                                <a href="#"><i class="arrow_right"></i></a>
                            </div>
                        </div>
    
                        <!-- Single Portfolio Slide -->
                        <div class="single-portfolio-slide">
                            <img src="/images/s4.jpg" alt="">
                            <!-- Overlay Effect -->
                            <div class="overlay-effect">
                                
                                
                            </div>
                            <!-- View More -->
                            <div class="view-more-btn">
                                <a href="#"><i class="arrow_right"></i></a>
                            </div>
                        </div>
    
                        <!-- Single Portfolio Slide -->
                        <div class="single-portfolio-slide">
                            <img src="/images/s5.jpg" alt="">
                            <!-- Overlay Effect -->
                            <div class="overlay-effect">
                                
                                
                            </div>
                            <!-- View More -->
                            <div class="view-more-btn">
                                <a href="#"><i class="arrow_right"></i></a>
                            </div>
                        </div>
    
                        
    
                    </div>
                </div>
            </div>
    </section>

        <!-- Border -->
        <div class="container">
            <div class="border-line"></div>
        </div>

        <!-- Background Curve -->
        <div class="portfolio-bg-curve">
            <img src="./img/core-img/curve-3.png" alt="">
        </div>
    </section>
    <!-- ***** Portfolio Area End ***** -->
    

    <!-- ***** Blog Area Start ***** -->
    <section class="uza-blog-area">
        <!-- Background Curve -->
        <div class="blog-bg-curve">
            <img src="./img/core-img/curve-4.png" alt="">
        </div>

    

    <?php $__env->stopSection(); ?>


    
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/newainet/resources/views/index.blade.php ENDPATH**/ ?>