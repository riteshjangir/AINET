<?php $__env->startSection('content'); ?>
<div class="all-title-box">
    <div class="container text-center">
        <h1  class="tai-mt-0">CONTACT US<span class="m_1"></span></h1>
    </div>
</div>
<!-- <div id="overviews" class="section lb"> -->
        <div class="container">  
                <form id="contact" action="" method="post">
                  <h3> Contact Us</h3>
                  <!-- <h4>Contact us today, and get reply with in 24 hours!</h4> -->
                  <fieldset>
                    <input placeholder="Your name" type="text" tabindex="1" required autofocus>
                  </fieldset>
                  <fieldset>
                    <input placeholder="Your Email Address" type="email" tabindex="2" required>
                  </fieldset>
                  <fieldset>
                    <input placeholder="Your Phone Number" type="tel" tabindex="3" required>
                  </fieldset>
                  <fieldset>
                    <input placeholder="Enter Your Subject" type="url" tabindex="4" required>
                  </fieldset>
                  <fieldset>
                    <textarea placeholder="Type your Message Here...." tabindex="5" required></textarea>
                  </fieldset>
                  <fieldset>
                    <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Submit</button>
                  </fieldset>
                </form>
               
                
              </div>
              <style>
                @import  url(https://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,600);
              
              * {
                  margin:0;
                  padding:0;
                  box-sizing:border-box;
                  -webkit-box-sizing:border-box;
                  -moz-box-sizing:border-box;
                  -webkit-font-smoothing:antialiased;
                  -moz-font-smoothing:antialiased;
                  -o-font-smoothing:antialiased;
                  font-smoothing:antialiased;
                  text-rendering:optimizeLegibility;
              }
              
              body {
                  font-family:"Open Sans", Helvetica, Arial, sans-serif;
                  font-weight:300;
                  font-size: 12px;
                  line-height:30px;
                  color:#777;
                  background:#0CF;
              }
              
              .container {
                  max-width:400px;
                  width:100%;
                  margin:0 auto;
                  position:relative;
              }
              
              #contact input[type="text"], #contact input[type="email"], #contact input[type="tel"], #contact input[type="url"], #contact textarea, #contact button[type="submit"] { font:400 12px/16px "Open Sans", Helvetica, Arial, sans-serif; }
              
              #contact {
                  background:#F9F9F9;
                  padding:25px;
                  margin:50px 0;
              }
              
              #contact h3 {
                  color: #F96;
                  display: block;
                  font-size: 30px;
                  font-weight: 400;
              }
              
              #contact h4 {
                  margin:5px 0 15px;
                  display:block;
                  font-size:13px;
              }
              
              fieldset {
                  border: medium none !important;
                  margin: 0 0 10px;
                  min-width: 100%;
                  padding: 0;
                  width: 100%;
              }
              
              #contact input[type="text"], #contact input[type="email"], #contact input[type="tel"], #contact input[type="url"], #contact textarea {
                  width:100%;
                  border:1px solid #CCC;
                  background:#FFF;
                  margin:0 0 5px;
                  padding:10px;
              }
              
              #contact input[type="text"]:hover, #contact input[type="email"]:hover, #contact input[type="tel"]:hover, #contact input[type="url"]:hover, #contact textarea:hover {
                  -webkit-transition:border-color 0.3s ease-in-out;
                  -moz-transition:border-color 0.3s ease-in-out;
                  transition:border-color 0.3s ease-in-out;
                  border:1px solid #AAA;
              }
              
              #contact textarea {
                  height:100px;
                  max-width:100%;
                resize:none;
              }
              
              #contact button[type="submit"] {
                  cursor:pointer;
                  width:100%;
                  border:none;
                  background:#0CF;
                  color:#FFF;
                  margin:0 0 5px;
                  padding:10px;
                  font-size:15px;
              }
              
              #contact button[type="submit"]:hover {
                  background:#09C;
                  -webkit-transition:background 0.3s ease-in-out;
                  -moz-transition:background 0.3s ease-in-out;
                  transition:background-color 0.3s ease-in-out;
              }
              
              #contact button[type="submit"]:active { box-shadow:inset 0 1px 3px rgba(0, 0, 0, 0.5); }
              
              #contact input:focus, #contact textarea:focus {
                  outline:0;
                  border:1px solid #999;
              }
              ::-webkit-input-placeholder {
               color:#888;
              }
              :-moz-placeholder {
               color:#888;
              }
              ::-moz-placeholder {
               color:#888;
              }
              :-ms-input-placeholder {
               color:#888;
              }
              
               </style>
    <!-- <div class="container"> -->
            <!-- <div class="section-title row text-center"> -->
                <!-- <div class="col-md-8 offset-md-2"> -->
                    <!-- <h2>4TH AINET INTERNATIONAL CONFERENCE</h2> -->
                    <!-- <h2>2-3 FEBRUARY 2018, MUMBAI</h2> -->
                    <!-- <p>Re-capture the memorable moments from the conference:</p> -->
                    <!-- <br> -->
                    <!-- <br> -->
                    <!-- <h3>AINET OP No. 1/ 2014</h3> -->
                    <!-- <a href="http://www.kes.ac.in/ainetDay1.php" target="_blank" rel="noopener"><span style="text-decoration: underline;"><span style="color: #0000ff; text-decoration: underline;">1.Photos from Day 1</span></span></a> -->
                    <!-- <a href="http://theainet.net/wp-content/uploads/2017/10/AINET-OP-1-Martin-Wedell-ITE-Curriculum.pdf"> <b>Martin Wedell</b>-<i>Initial English Teacher Education and English Curriculum Goals: Bridging the Gap</i></a> -->
                    <!-- <br> -->
                    <!-- <br> -->
                    <!-- <br> -->
                    <!-- <h3>AINET OP No. 2/ 2016</h3> -->
                    <!-- <a href="http://www.kes.ac.in/ainetDay2.php" target="_blank" rel="noopener"><span style="text-decoration: underline;"><span style="color: #0000ff; text-decoration: underline;">2.Photos from Day 2</span></span></a> -->
                   <!-- <br> -->
                   <!-- <a href="https://youtube.com/channel/UCQmSaAfIRk_WnU6tlBmYS1Q" target="_blank" rel="noopener"><span style="text-decoration: underline;"><span style="color: #0000ff; text-decoration: underline;">3.Some select videos</span></span></a> -->
                   <!-- <br> -->
                   <!-- <br> -->
                   <!-- <a href="http://conf.theainet.net"><span style="text-decoration: underline;">Go to the Conference site</span></a> -->
                <!-- </a> -->
                <!-- for other information and updates. -->
                   <!-- <a href="http://theainet.net/wp-content/uploads/2017/10/AINET-OP-1-Martin-Wedell-ITE-Curriculum.pdf"> <b>Krishna Dixit</b>-<i>Teacher Motivation: A Conceptual Overview</i></a> -->
                    <!-- <div class="row align-items-center">
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
            <div class="message-box">
                <h4 class="footer-center1" >UPDATES</h4> -->
                <!-- <ul>
                        <a href="#"><li> Recent Publications – AINET Occasional Paper 2 (Teacher Motivation – A Conceptual Overview); Exploring Learners and Learning of English (2017 Conf Selections)</li></a>

                    </ul> -->
                   
                <!-- <h2>WHAT IS AINET?</h2> -->

                <!-- <p>AINET is an online pan-India community of people interested in the teaching and learning of English in India – teachers, trainers, teacher educators, publishers, policy makers, educational authorities, researchers, students, private tutors and free-lancers.</p>
                <p>We welcome anyone who wishes to promote the growth of the teachers and learners of English, including their own, to be a part of this community.</p>
                <p>AINET is an associate of the International Association of Teachers of English as a Foreign Language (IATEFL), UK. AINET evolved out of a Hornby Alumni Project undertaken by Dr. Amol Padwad (amolpadwad@gmail.com) and Krishna Dixit (krishnakdixit@gmail.com).</p> -->


                <!-- <p> Integer rutrum ligula eu dignissim laoreet. Pellentesque venenatis nibh sed tellus faucibus bibendum. Sed fermentum est vitae rhoncus molestie. Cum sociis natoque penatibus et magnis montes, nascetur ridiculus mus. Sed vitae rutrum neque. </p> -->

                <!-- <a href="#" class="hover-btn-new orange"><span>Learn</span></a> -->
            </div><!-- end messagebox -->
        </div><!-- end col -->
        
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
            <div class="post-media wow fadeIn">
                <!-- <img src="images/q1.jpg" alt="" class="img-fluid img-rounded"> -->
            </div><!-- end media -->
        </div><!-- end col -->
    </div>


    <!-- <div class="row align-items-center">
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
            <div class="post-media wow fadeIn">
                <img src="images/q2.jpg" alt="" class="img-fluid img-rounded">
            </div>end media
        </div>end col
        
        < <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
            <div class="message-box">
                <h2>WHY AINET?</h2>
                <p> AINET offers an effective avenue for professional networking and growth for a geographically vast and diverse country like India with the advantage of high speed at low costs.</p>

                <p> AINET brings you resources, information, support and professional networking, which will enable you to grow and to take your career/ interest to greater height and depth.</p> -->

                <!-- <a href="#" class="hover-btn-new orange"><span>Learn More</span></a> -->
            </div><!-- end messagebox -->
        </div><!-- end col -->
        
    </div><!-- end row -->
</div><!-- end container -->
<!-- </div>end section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/theainet/resources/views/contact.blade.php ENDPATH**/ ?>