<?php $__env->startSection('content'); ?>
<!-- Modal -->


	
	<div id="carouselExampleControls" class="carousel slide bs-slider box-slider" data-ride="carousel" data-pause="hover"
		data-interval="false">
		<!-- Indicators -->
		<ol class="carousel-indicators">
			<li data-target="#carouselExampleControls" data-slide-to="0" class="active"></li>
			<li data-target="#carouselExampleControls" data-slide-to="1" class="active"></li>
			<li data-target="#carouselExampleControls" data-slide-to="2" class="active"></li>
			<li data-target="#carouselExampleControls" data-slide-to="3" class="active"></li>
			<li data-target="#carouselExampleControls" data-slide-to="4" class="active"></li>
			<li data-target="#carouselExampleControls" data-slide-to="5" class="active"></li>
			<!-- <li data-target="#carouselExampleControls" data-slide-to="6"></li> -->


		</ol>
		<div class="carousel-inner" role="listbox">
			<div class="carousel-item active">
				<div id="home" class="first-section" style="background-image:url('images/s12.jpg');">
					<div class="dtab">
						<div class="container">
							<div class="row">
								<div class="col-md-12 col-sm-12 text-right">
									<div class="big-tagline">
										<!-- <h2><strong>AINET </strong> </h2> -->
										<p class="lead"> </p>
										<!-- <a href="#" class="hover-btn-new"><span>Contact Us</span></a>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<a href="#" class="hover-btn-new"><span>Read More</span></a> -->
									</div>
								</div>
							</div><!-- end row -->
						</div><!-- end container -->
					</div>
				</div><!-- end section -->
			</div>
			<div class="carousel-item">
				<div id="home" class="first-section" style="background-image:url('images/s11.jpg');">
					<div class="dtab">
						<div class="container">
							<div class="row">
								<div class="col-md-12 col-sm-12 text-left">
									<!-- <div class="big-tagline">
										<h2 data-animation="animated zoomInRight">AINET <strong>education school</strong></h2>
										<p class="lead" data-animation="animated fadeInLeft">With Landigoo responsive landing page template, you can promote your all hosting, domain and email services. </p>
											<a href="#" class="hover-btn-new"><span>Contact Us</span></a>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<a href="#" class="hover-btn-new"><span>Read More</span></a>
									</div> -->
								</div>
							</div><!-- end row -->
						</div><!-- end container -->
					</div>
				</div><!-- end section -->
			</div>
			<div class="carousel-item">
				<div id="home" class="first-section" style="background-image:url('images/s14.jpg');">
					<div class="dtab">
						<div class="container">
							<div class="row">
								<div class="col-md-12 col-sm-12 text-center">
									<!-- <div class="big-tagline">
										<h2 data-animation="animated zoomInRight"><strong>VPS Servers</strong> Company</h2>
										<p class="lead" data-animation="animated fadeInLeft">1 IP included with each server 
											Your Choice of any OS (CentOS, Windows, Debian, Fedora)
											FREE Reboots</p>
											<a href="#" class="hover-btn-new"><span>Contact Us</span></a>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<a href="#" class="hover-btn-new"><span>Read More</span></a>
									</div> -->
								</div>
							</div><!-- end row -->
						</div><!-- end container -->
					</div>
				</div><!-- end section -->
			</div>
			<!-- //s4 -->
			<div class="carousel-item">
				<div id="home" class="first-section" style="background-image:url('images/s15.jpg');">
					<div class="dtab">
						<div class="container">
							<div class="row">
								<div class="col-md-12 col-sm-12 text-center">
									<!-- <div class="big-tagline">
										<h2 data-animation="animated zoomInRight"><strong>VPS Servers</strong> Company</h2>
										<p class="lead" data-animation="animated fadeInLeft">1 IP included with each server 
											Your Choice of any OS (CentOS, Windows, Debian, Fedora)
											FREE Reboots</p>
											<a href="#" class="hover-btn-new"><span>Contact Us</span></a>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<a href="#" class="hover-btn-new"><span>Read Moe</span></a>
									</div> -->
								</div>
							</div><!-- end row -->
						</div><!-- end container -->
					</div>
				</div><!-- end section -->
			</div>
			<!-- s5 -->
			<div class="carousel-item">
				<div id="home" class="first-section" style="background-image:url('images/s16.jpg');">
					<div class="dtab">
						<div class="container">
							<div class="row">
								<div class="col-md-12 col-sm-12 text-center">
									<!-- <div class="big-tagline">
										<h2 data-animation="animated zoomInRight"><strong>VPS Servers</strong> Company</h2>
										<p class="lead" data-animation="animated fadeInLeft">1 IP included with each server 
											Your Choice of any OS (CentOS, Windows, Debian, Fedora)
											FREE Reboots</p>
											<a href="#" class="hover-btn-new"><span>Contact Us</span></a>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<a href="#" class="hover-btn-new"><span>Read More</span></a>
									</div> -->
								</div>
							</div><!-- end row -->
						</div><!-- end container -->
					</div>
				</div><!-- end section -->
			</div>
			<div class="carousel-item">
				<div id="home" class="first-section" style="background-image:url('images/s17.jpg');">
					<div class="dtab">
						<div class="container">
							<div class="row">
								<div class="col-md-12 col-sm-12 text-center">
									<!-- <div class="big-tagline">
										<h2 data-animation="animated zoomInRight"><strong>VPS Servers</strong> Company</h2>
										<p class="lead" data-animation="animated fadeInLeft">1 IP included with each server 
											Your Choice of any OS (CentOS, Windows, Debian, Fedora)
											FREE Reboots</p>
											<a href="#" class="hover-btn-new"><span>Contact Us</span></a>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<a href="#" class="hover-btn-new"><span>Read More</span></a>
									</div> -->
								</div>
							</div><!-- end row -->
						</div><!-- end container -->
					</div>
				</div><!-- end section -->
			</div>
			<!-- Left Control -->
			<a class="new-effect carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
				<span class="fa fa-angle-left" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>

			<!-- Right Control -->
			<a class="new-effect carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
				<span class="fa fa-angle-right" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>
	</div>

	<div class="section w3-white">
		<div class="container">

			<div class="row">
				<div class="col-md-8 w3-text-orange">
						<div class="widget-title">
								<h3>About US</h3>
							</div>
							<p> AINET is an online pan-India community of people interested in the teaching and learning of
								English in India – teachers, trainers, teacher educators, publishers, policy makers,
								educational authorities, researchers, students, private tutors and free-lancers. We welcome
								anyone who wishes to promote the growth of the teachers and learners of English, including
								their own, to be a part of this community. AINET is an associate of the International
								Association of Teachers of English as a Foreign Language (IATEFL), UK. AINET evolved out of
								a Hornby Alumni Project undertaken by Dr. Amol Padwad (amolpadwad@gmail.com) and Krishna
								Dixit (krishnakdixit@gmail.com).</p>
							<div class="footer-right">
								<ul class="footer-links-soi">
									<li><a href="https://www.facebook.com/ainetindia/"><i class="fa fa-facebook"></i></a>
									</li>
									<!-- <li><a href="#"><i class="fa fa-github"></i></a></li> -->
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-youtube"></i></a></li>
									<!-- <li><a href="#"><i class="fa fa-pinterest"></i></a></li> -->
								</ul><!-- end links -->
							</div>
				</div>
				<div class="col-md-4">
					<div class="w3-text-white w3-center w3-margin-bottom w3-orange w3-round w3-padding"
						style="font-size: 24px">Member Login</div>
						<form method="POST" action="<?php echo e(route('login')); ?>">
							<?php echo csrf_field(); ?>
							<div class="form-group">
								<label for="email" class="w3-text-orange"><?php echo e(__('E-Mail Address')); ?></label>
								<input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
								<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
									<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
							<div class="form-group">
								<label for="password" class="w3-text-orange"><?php echo e(__('Password')); ?></label>			
								<input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password">
								<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
									<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
							<div class="form-group">
								<div class="form-check">
									<input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
									<label class="form-check-label w3-text-orange" for="remember">
										<?php echo e(__('Remember Me')); ?>

									</label>
								</div>
							</div>
							<div class="form-group">
								<button type="submit" class="btn w3-orange w3-hover-white w3-large"><?php echo e(__('Login')); ?></button>
								<?php if(Route::has('password.request')): ?>
									<a class="btn w3-text-orange" href="<?php echo e(route('password.request')); ?>">
										<?php echo e(__('Forgot Your Password?')); ?>

									</a>
								<?php endif; ?>
							</div>
							<?php if(Route::has('register')): ?>
								<a href="<?php echo e(route('register')); ?>" class="btn w3-hover-orange w3-border w3-border-orange w3-text-orange btn-block">Get A Membership</a>
							<?php endif; ?>
						</form>
				</div>
			</div>
		</div><!-- end row -->
	</div><!-- end container -->

	<div id="testimonials" class="parallax section db parallax-off" style="background-image:url('images/logo1.png');">
		<div class="container">

			<div class="row">
				<div class="col-md-7">
					<div class="card">
						<img class="card-img-top" src="images/announ.jpg" alt="">
					</div>
				</div>
				<div class="col-md-5  w3-text-orange w3-center mt-5 pt-5">
						<div class="widget-title">
								<h1 class="w3-text-white">Announcement</h1>
							</div>
							
							<div class="footer-right">
								<a href="/announcementtwo" class="btn w3-orange">Click Here TO Fill Form</a>
							</div>
				</div>
			</div>
		</div><!-- end row -->
	</div><!-- end container -->

	<div class="section w3-white">
			<div class="container">
	
				<div class="row">
					<div class="col-md-5 w3-text-orange">
						<h1 class="w3-text-orange w3-center mt-5 pt-5">5th AINET Conference</h1>
						<h3 class="w3-text-orange w3-center">On 09 And 10 July 2020</h3>
						<h3 class="w3-text-orange w3-center">At Vasavi College Of Engineering Hyderabad</h3>
					</div>
					<div class="col-md-7">
						<div class="card">
							<img class="card-img-top" src="images/blog_2.jpg" alt="">
						</div>
					</div>
				</div>
			</div><!-- end row -->
		</div><!-- end container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\PleskVhosts\theainet.net\httpdocs\theainet\resources\views/welcome.blade.php ENDPATH**/ ?>