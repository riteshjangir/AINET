<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center mt-5 mb-5">
        <div class="col-md-8">
            <div class="card w3-border-orange">
                <div class="card-header w3-orange w3-border-orange"><?php echo e(__('Become A Member')); ?></div>

                <div class="card-body">
                    
                    The Membership Area Is Launching On 5 August
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/theainet/resources/views/auth/register.blade.php ENDPATH**/ ?>