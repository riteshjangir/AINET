<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>


    <!-- ***** Welcome Area Start ***** -->
    <section class="welcome-area">
        <div class="welcome-slides owl-carousel">

            <!-- Single Welcome Slide -->
            <div class="single-welcome-slide">
                <!-- Background Curve -->
                <div class="background-curve">
                    <img src="./img/core-img/curve-1.png" alt="">
                </div>

                
                <!-- Welcome Content -->
                
                <div class="welcome-content h-100">
                      
                    
                    <div class="container h-100">
                        
                        <div class="row h-100 align-items-center">
                            <!-- Welcome Text -->
                            <div class="col-12 col-md-6">
                                <div class="welcome-text">
                                        <h1 style="color:#9900FF;">Join a vibrant community of english language education professionals.

                                            </h1><br>
									
                                            <h1 style="color:#0000FF;">Develop. Together.
                                                </h1>
                                        
                                </div>
                            </div>
                            <!-- Welcome Thumbnail -->
                            <div class="col-12 col-md-6">
                                <div class="welcome-thumbnail">
                                    <img src="/images/l1.gif" alt="" data-animation="slideInTop" data-delay="100ms">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            

           
        </div>
    </section>

<!-- <div class=" ">
    <div class="single-footer-widget mb-80"> -->
        <!-- Widget Title -->
                <!-- <div class="section-heading text-center">
                    <h4>Become&nbsp;&nbsp;&nbsp; A &nbsp;&nbsp;Member </h4>
                    <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;S&nbsp;&nbsp;I &nbsp;&nbsp;G&nbsp;&nbsp; N&nbsp;&nbsp; U&nbsp;&nbsp; P&nbsp;&nbsp;</h4>
   
    </div>
</div> -->
<div class="container-fluid text-center">
    <!-- Control the column width, and how they should appear on different devices -->

    <div class="text-join"> 
        <font style="background-color:#DF068C; font-size: 40px; padding: 20px 0px 20px 0px;" color="white">
          <a class="text-join" href="#"><b>Member Area</b></a> 
        </font>
      </div>

    </div>

     <!-- <div class="row">
      <div class="col-sm-1.5" style="background-color:black;"><font color="white">L&nbsp;&nbsp;&nbsp;O&nbsp;&nbsp;&nbsp;G&nbsp;&nbsp;&nbsp;&nbsp;I&nbsp;&nbsp;N</font></div>

    </div> -->
    <!-- ***** Welcome Area End ***** -->
<br/><br/>
  
                  <hr>

<div class="col-12">
                    <div class="single-footer-widget mb-80">
                        <!-- Widget Title -->
                                <div class="section-heading text-center">
                                    <h2>Follow us</h2><br>
                        <div class="footer-social-info">
                            <a href="https://www.facebook.com/ainetindia/" class="facebook" data-toggle="tooltip" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a>fb.com/ainetindia&nbsp;&nbsp;
                            <a href="https://twitter.com/ainetindia" class="twitter" data-toggle="tooltip" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a>@ainetindia&nbsp;&nbsp;
                            
                            <a href="https://www.instagram.com/ainet_india/" class="instagram" data-toggle="tooltip" data-placement="top" title="Instagram"><i class="fa fa-instagram"></i></a>ainet_india&nbsp;&nbsp;
                            <a href="https://www.youtube.com/channel/UCHaFX92EaJzFL7m7fPD591A" class="youtube" data-toggle="tooltip" data-placement="top" title="YouTube"><i class="fa fa-youtube-play"></i></a>AINET India&nbsp;&nbsp;
                            <a href="#" class="rssfeed" data-toggle="tooltip" data-placement="top" title="RSSFeed"><i class="fa fa-rss"></i></a>AINET_RSSFeed&nbsp;&nbsp;

                        </div>
                    </div>
                </div>
    <!-- ***** About Us Area Start ***** -->
    <section class="uza-about-us-area">
        <div class="container">
            <div class="row align-items-center">

                <!-- About Thumbnail -->
                <div class="col-12 col-md-6">
                    <div class="about-us-thumbnail mb-80">
                        
                        <!-- Video Area -->
                        
                    </div>
                </div>

                <!-- About Us Content -->
                <div class="col-12 col-md-6">
                    <div class="about-us-content mb-80">
                        <h2>
                                
                        
                        

                    </div>
                </div>
            </div>
        </div>

        <!-- About Background Pattern -->
        
    <!-- ***** About Us Area End ***** -->

    

    <!-- ***** Portfolio Area Start ***** -->
    <section class="uza-portfolio-area section-padding-80">
        <div class="container">
            <div class="row">
                <!-- Section Heading -->
                <div class="col-12">
                    <div class="section-heading text-center">
                        <h2>AINET INITIATIVES</h2>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <!-- Portfolio Slides -->
                <div class="portfolio-sildes owl-carousel">

                    <!-- Single Portfolio Slide -->
                    <div class="single-portfolio-slide">
                        <img src="./img/bg-img/ CONNET.JPG" alt="">
                        <!-- Overlay Effect -->
                        <div class="overlay-effect">
                            <h4>AINET CONNECT</h4>
      
                        </div>
                        <!-- View More -->
                        <div class="view-more-btn">
                            <a href="#"><i class="arrow_right"></i></a>
                        </div>
                    </div>
					
                    <!-- Single Portfolio Slide -->
                    <div class="single-portfolio-slide">
                        <img src="./img/bg-img/TRI.JPG" alt="">
                        <!-- Overlay Effect -->
                        <div class="overlay-effect">
                            <h4>AINET TRI</h4>
      
                        </div>
                        <!-- View More -->
                        <div class="view-more-btn">
                            <a href="#"><i class="arrow_right"></i></a>
                        </div>
                    </div>

                   
                    


                </div>
            </div>
        </div>

        <!-- Client Feedback Area Start -->
        <div class="clients-feedback-area mt-80 section-padding-80 clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-12">
  <div class="section-heading text-center">
                        <h2> Testimonials</h2>
                    </div>
                        <!-- Testimonial Slides -->
                        <div class="testimonial-slides owl-carousel">

                            <!-- Single Testimonial Slide -->
                            <div class="single-testimonial-slide d-flex align-items-center">
                                <!-- Testimonial Thumbnail -->
                                <div class="testimonial-thumbnail">
                                    <img src="./img/bg-img/T1.JPG" alt="">
                                </div>
                                <!-- Testimonial Content -->
                                <div class="testimonial-content">
                                    <h4>"AINET has always provided a huge platform for the professional development of hard working teachers. It has constantly supported all its associated teachers to grow to greater heights. For me, it is the first and the best organization to to boost my research skills. It has done everything for me that parents do for the bright future of a child!"</h4>
                                    <!-- Ratings -->
                                    <div class="ratings">
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                    </div>
                                    <!-- Author Info -->
                                    <div class="author-info">
                                        <h5>Darshana Bapat, Ratnagiri <span>- </span></h5>
                                    </div>
                                    <!-- Quote Icon -->
                                    <div class="quote-icon"><img src="img/core-img/quote.png" alt=""></div>
                                </div>
                            </div>

                            <!-- Single Testimonial Slide -->
                            <div class="single-testimonial-slide d-flex align-items-center">
                                <!-- Testimonial Thumbnail -->
                                <div class="testimonial-thumbnail">
                                    <img src="./img/bg-img/T2.JPG" alt="">
                                </div>
                                <!-- Testimonial Content -->
                                <div class="testimonial-content">
                                    <h4>“My association with AINET has been an utter joy. As an illustration I have gone from being a teacher to becoming a teacher researcher and a mentor in no more than a year. AINET's work is very structured, clear, logical and effective when it comes to organising any workshop or conference. AINET has played a major role in my CPD.”</h4>
                                    <!-- Ratings -->
                                    <div class="ratings">
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                    </div>
                                    <!-- Author Info -->
                                    <div class="author-info">
                                        <h5>Renu Dhotre, Mumbai <span></span></h5>
                                    </div>
                                    <!-- Quote Icon -->
                                    <div class="quote-icon"><img src="img/core-img/quote.png" alt=""></div>
                                </div>
                            </div>
                            <!-- Single Testimonial Slide -->
                            <div class="single-testimonial-slide d-flex align-items-center">
                                    <!-- Testimonial Thumbnail -->
                                    <div class="testimonial-thumbnail">
                                        <img src="./img/bg-img/T3.JPG" alt="">
                                    </div>
                                    <!-- Testimonial Content -->
                                    <div class="testimonial-content">
                                        <h4>“The support AINET gave me and the knwoledge they provided me with really transformed the way in which I run my teacher club in Latur and ensure that I have time to devote to what matters most. AINET conferences helped me improve my strategic planning and project management skills. Truly life changing!”</h4>
                                        <!-- Ratings -->
                                        <div class="ratings">
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                        </div>
                                        <!-- Author Info -->
                                        <div class="author-info">
                                            <h5>Prashant Mugale, Latur <span></span></h5>
                                        </div>
                                        <!-- Quote Icon -->
                                        <div class="quote-icon"><img src="img/core-img/quote.png" alt=""></div>
                                    </div>
                                </div>
                                <!-- Single Testimonial Slide -->
                            <div class="single-testimonial-slide d-flex align-items-center">
                                    <!-- Testimonial Thumbnail -->
                                    <div class="testimonial-thumbnail">
                                        <img src="./img/bg-img/T4.JPG" alt="">
                                    </div>
                                    <!-- Testimonial Content -->
                                    <div class="testimonial-content">
                                        <h4>“AINET's management system and AINET Team's work with our teacher leaders to customize these systems to their own personal styles has significantly improved the quality of teachers in my ATM teachers' group. Teachers feel more organized and more productive, using practices learned from AINET projects.”</h4>
                                        <!-- Ratings -->
                                        <div class="ratings">
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                        </div>
                                        <!-- Author Info -->
                                        <div class="author-info">
                                            <h5>Vikram Adsul, Ahmednagar <span></span></h5>
                                        </div>
                                        <!-- Quote Icon -->
                                        <div class="quote-icon"><img src="img/core-img/quote.png" alt=""></div>
                                    </div>
                                </div>
                                <!-- Single Testimonial Slide -->
                            <div class="single-testimonial-slide d-flex align-items-center">
                                    <!-- Testimonial Thumbnail -->
                                    <div class="testimonial-thumbnail">
                                        <img src="./img/bg-img/T5.JPG" alt="">
                                    </div>
                                    <!-- Testimonial Content -->
                                    <div class="testimonial-content">
                                        <h4>“AINET's Teacher Research Initiative armed me with practical tools and strategies that have made an immediate impact on the overall effectiveness of my thinking and teaching. Working with AINET engaged me in a process of learning-unlearning and relearning and rediscover myself. It was not only highly effective but also highly enjoyable!”</h4>
                                        <!-- Ratings -->
                                        <div class="ratings">
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                        </div>
                                        <!-- Author Info -->
                                        <div class="author-info">
                                            <h5>Rohini Deshmukh Sankpal, Kolhapur <span></span></h5>
                                        </div>
                                        <!-- Quote Icon -->
                                        <div class="quote-icon"><img src="img/core-img/quote.png" alt=""></div>
                                    </div>
                                </div>

                            <!-- Single Testimonial Slide -->
                            <div class="single-testimonial-slide d-flex align-items-center">
                                <!-- Testimonial Thumbnail -->
                                <div class="testimonial-thumbnail">
                                    <img src="./img/bg-img/T6.JPG" alt="">
                                </div>
                                <!-- Testimonial Content -->
                                <div class="testimonial-content">
                                    <h4>“I honestly can’t explain how thankful I am. This really opened my eyes to actually being able to become a reflective practitioner..”</h4>
                                    <!-- Ratings -->
                                    <div class="ratings">
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                    </div>
                                    <!-- Author Info -->
                                    <div class="author-info">
                                        <h5>Dr. Bhavna Rai, Bhandara <span></span></h5>
                                    </div>
                                    <!-- Quote Icon -->
                                    <div class="quote-icon"><img src="img/core-img/quote.png" alt=""></div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Client Feedback Area End -->
         <!-- ***** Portfolio Area Start ***** -->
    <section class="uza-portfolio-area section-padding-80">
            <div class="container">
                <div class="row">
                    <!-- Section Heading -->
                    <div class="col-12">
                        <div class="section-heading text-center">
                            <h2>AINET  Gallery</h2> 
                            
                        </div>
                    </div>
                </div>
            </div>
    
            <div class="container-fluid">
                <div class="row">
                    <!-- Portfolio Slides -->
                    <div class="portfolio-sildes owl-carousel">
    
                        <!-- Single Portfolio Slide -->
                        <div class="single-portfolio-slide">
                            <img src="/images/s3.jpg" alt="">
                            <!-- Overlay Effect -->
                            <div class="overlay-effect">
                                
                                
                            </div>
                            <!-- View More -->
                            <div class="view-more-btn">
                                <a href="#"><i class="arrow_right"></i></a>
                            </div>
                        </div>
    
                        <!-- Single Portfolio Slide -->
                        <div class="single-portfolio-slide">
                            <img src="/images/s4.jpg" alt="">
                            <!-- Overlay Effect -->
                            <div class="overlay-effect">
                                
                                
                            </div>
                            <!-- View More -->
                            <div class="view-more-btn">
                                <a href="#"><i class="arrow_right"></i></a>
                            </div>
                        </div>
    
                        <!-- Single Portfolio Slide -->
                        <div class="single-portfolio-slide">
                            <img src="/images/s5.jpg" alt="">
                            <!-- Overlay Effect -->
                            <div class="overlay-effect">
                                
                                
                            </div>
                            <!-- View More -->
                            <div class="view-more-btn">
                                <a href="#"><i class="arrow_right"></i></a>
                            </div>
                        </div>
    
                        
    
                    </div>
                </div>
            </div>
    </section>

        <!-- Border -->
        <div class="container">
            <div class="border-line"></div>
        </div>

        <!-- Background Curve -->
        <div class="portfolio-bg-curve">
            <img src="./img/core-img/curve-3.png" alt="">
        </div>
    </section>
    <!-- ***** Portfolio Area End ***** -->
    

    <!-- ***** Blog Area Start ***** -->
    <section class="uza-blog-area">
        <!-- Background Curve -->
        <div class="blog-bg-curve">
            <img src="./img/core-img/curve-4.png" alt="">
        </div>

    

    <?php $__env->stopSection(); ?>


    
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\PleskVhosts\theainet.net\newainet\resources\views/index.blade.php ENDPATH**/ ?>