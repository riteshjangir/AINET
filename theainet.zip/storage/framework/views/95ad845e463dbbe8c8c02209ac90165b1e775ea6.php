<?php $__env->startSection('content'); ?>
<div class="all-title-box" style="background: url('images/ainet-logo-fb.png');background-size: contain;
    background-repeat: no-repeat;
    background-position: center;">
    <div class="container text-center">
    </div>
</div>
<div id="overviews" class="section lb">
    <div class="container">
        <div class="section-title row text-center">
            <div class="col-md-8 offset-md-2">
                <h3>AINET CPD POSTERS</h3>
                <br>
                <h4>AINET has brought out a set of FOUR very attractive and meaningful posters on CPD.</h4>
                <br>
                <h4>Cost of the poster: Rs. 150 each (Free delivery in India)</h4>

                <h4>Cost of the set (4 posters): Rs. 300 (Free delivery in India)</h4>
                <br>
                <h4>Write to <b>theainet@gmail.com</b> to place your order.</h4>
                <br>
                <h4> <a href="#">1.CPD POSTER 1</a>
                </h4>
                <!-- <h2>1.CPD POSTER 1</h2> -->
                <h4> <a href="#">2.CPD POSTER
                        2</a></h4>
                <!-- <h2>3.CPD POSTER 3</h2> -->
                <h4> <a href="#">3.CPD POSTER
                        3</a></h4>

                <!-- <h2>4.CPD POSTER 4</h2> -->
                <h4> <a href="#">4.CPD POSTER 4</a>
                </h4>


             
            </div><!-- end messagebox -->
        </div><!-- end col -->
		
		

 
        </div><!-- end col -->
	
    </div>
<br>

			
			


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\PleskVhosts\theainet.net\newainet\resources\views/publicationtwo.blade.php ENDPATH**/ ?>