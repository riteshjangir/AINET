<?php $__env->startSection('content'); ?>
    
    <!-- ***** Breadcrumb Area Start ***** -->
    <div class="breadcrumb-area">
        <div class="container h-100">
            <div class="row h-100 align-items-end">
                <div class="col-12">
                    <div class="breadcumb--con">
                        <h2 class="title">FAQ
                        </h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">FAQ
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <!-- Background Curve -->
        <div class="breadcrumb-bg-curve">
            <img src="./img/core-img/curve-5.png" alt="">
        </div>
    </div>
    <!-- ***** Breadcrumb Area End ***** -->

    <!-- ***** Services Area Start ***** -->
    <section class="uza-services-area section-padding-80-0">
        <div class="container">
            <div class="row">

                <!-- Single Service Area -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-service-area mb-80">
                        <!-- Service Icon -->
                        <div class="service-icon">
                            <i class="icon_cone_alt"></i>
                        </div>
                        <h5>What Is AINET?</h5>
                        <p>AINET is an online pan-india community of people interested in the teaching and learning of english in india – teachers, trainers, teacher educators, publishers, policy makers, educational authorities, researchers, students, private tutors and free-lancers. We welcome anyone who wishes to promote the growth of the teachers and learners of english, including their own, to be a part of this community. AINET is an associate of the international association of teachers of english as a foreign language (iatefl), uk. AINET evolved out of a hornby alumni project undertaken by dr. amol padwad (amolpadwad@gmail.com) and krishna dixit (krishnakdixit@gmail.com).</p>
                    </div>
                </div>

                <!-- Single Service Area -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-service-area mb-80">
                        <!-- Service Icon -->
                        <div class="service-icon">
                            <i class="icon_piechart"></i>
                        </div>
                        <h5>Why AINET</h5>
                        <p>AINET offers an effective avenue for professional networking and growth for a geographically vast and diverse country like india with the advantage of high speed at low costs. AINET brings you resources, information, support and professional networking, which will enable you to grow and to take your career/ interest to greater height and depth.</p>
                    </div>
                </div>

                <!-- Single Service Area -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-service-area mb-80">
                        <!-- Service Icon -->
                        <div class="service-icon">
                            <i class="icon_easel"></i>
                        </div>
                        <h5>what does the AINET offer ?</h5>
                        <p>Regular newsletters, information on events, courses, scholarships, publications, job opportunities, discussion forums, help in research and publication, journals and publications, online resources for teaching-learning english, support for organising academic (elt) events, online help to improve your english and your teaching.</p>
                    </div>
                </div>

                <!-- Single Service Area -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-service-area mb-80">
                        <!-- Service Icon -->
                        <div class="service-icon">
                            <i class="icon_lightbulb_alt"></i>
                        </div>
                        <h5>Who can join AINET ?</h5>
                        <p>AINET is open to everyone concerned/related with teaching and learning of english – teachers of english at all levels, teacher educators, materials writers, trainers and consultants, free-lance practitioners, educational authorities associated with elt, institutions and bodies, publishers, elt service providers and even lay persons.
                        </p>
                    </div>
                </div>

                <!-- Single Service Area -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-service-area mb-80">
                        <!-- Service Icon -->
                        <div class="service-icon">
                            <i class="icon_drawer_alt"></i>
                        </div>
                        <h5>How do i join Ainet ?</h5>
                        <p>At the moment ainet does not have any formal membership. We will update this space and also on public forums when we launch our membership. To join us please register your email id with us (link on home page) and also like our facebook page.
                        </p>
                    </div>
                </div>

                

            </div>
        </div>
    </section>
    <?php $__env->stopSection(); ?>

   
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\newainet\resources\views/about2.blade.php ENDPATH**/ ?>