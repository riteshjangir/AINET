<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ppf extends Model
{
    //
}
