
   @extends('layouts.app1')
   @section('content')
       
     <style>
            /* btn */
            .button {
  border-radius: 4px;
  background-color: #00BFFF;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 28px;
  padding: 10px;
  width: 100px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
            /* btn */
        * {
          box-sizing: border-box;
        }
        
        body {
          font-family: Arial, Helvetica, sans-serif;
        }
        
        /* Float four columns side by side */
        .column {
          float: left;
          width: 25%;
          padding: 0 10px;
        }
        
        /* Remove extra left and right margins, due to padding */
        .row {margin: 0 -5px;}
        
        /* Clear floats after the columns */
        .row:after {
          content: "";
          display: table;
          clear: both;
        }
        
        /* Responsive columns */
        @media screen and (max-width: 600px) {
          .column {
            width: 100%;
            display: block;
            margin-bottom: 20px;
          }
        }
        
        /* Style the counter cards */
        .card {
          box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
          padding: 16px;
          text-align: center;
          background-color: #E51284;
          color: aliceblue;
        
        }
        .card-one {
          box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
          padding: 16px;
          text-align: center;
          background-color: #E51284;
          color:#9400d3	;
        
        }
        h3{
            color: aliceblue;
        }

        .inv {
            color: #004798;
            
        }
			.wh{
				color:#FFFFFF	;
			}
			.wh1{
				color:#e7f2fd;
			}
        </style>
   {{-- <link rel="stylesheet" type="text/css" href="register.css" /> --}}

   <!-- ***** Breadcrumb Area Start ***** -->
    <div class="breadcrumb-area">
        <div class="container h-100">
            <div class="row h-100 align-items-end">
                <div class="col-12">
                    <div class="breadcumb--con">
                        <h2 class="title">Membership</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/"><i class="fa fa-home"></i> Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Membership</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
		</div>

        <meta name="viewport" content="width=device-width, initial-scale=1">

      
		   <div class="container h-100">
                            <h2>Membership privileges:</h2>
                <h4>As an AINET member, you will</h4>
                <ul>
                    <li><i class='fa fa-angle-double-right' style='font-size:28px;color:#DF068C;'></i>&nbsp;&nbsp;<b style='font-size:18px'>Become part of a large and vibrant ELE community in India and globally.</b></li><br>
                    <li><i class='fa fa-angle-double-right' style='font-size:28px;color:#DF068C;'></i>&nbsp;&nbsp;<b style='font-size:18px'>Get regular information about AINET events, activities and offerings.</b></li><br>
                    <li><i class='fa fa-angle-double-right' style='font-size:28px;color:#DF068C;'></i>&nbsp;&nbsp;<b style='font-size:18px'>Get membership discounts and benefits at AINET events and other collaborative events.</b></li><br>
                    <li><i class='fa fa-angle-double-right' style='font-size:28px;color:#DF068C;'></i>&nbsp;&nbsp;<b style='font-size:18px'>Receive AINET publications, newsletters and other products free or at discounted prices.</b></li><br>
                    <li><i class='fa fa-angle-double-right' style='font-size:28px;color:#DF068C;'></i>&nbsp;&nbsp;<b style='font-size:18px'>Have access to the Member's Area with special services and resources available for members only.</b></li><br>
                    <li><i class='fa fa-angle-double-right' style='font-size:28px;color:#DF068C;'></i>&nbsp;&nbsp;<b style='font-size:18px'>Be eligible to join IATEFL at heavily discounted rate under the Wider Membership Scheme.</b></li><br>
                    <li><i class='fa fa-angle-double-right' style='font-size:28px;color:#DF068C;'></i>&nbsp;&nbsp;<b style='font-size:18px'>Be eligible to apply for various AINET scholarships, travel grants and other kinds of support.</b></li><br>
                </ul>
			   </div>
        <div class="breadcrumb-area">
        <div class="container h-100">
            <div class="row h-100 align-items-end">
                <div class="col-12">        
        <h2 class="inv">Individual Membership Type</h2>&nbsp;&nbsp;&nbsp;&nbsp;
        
        <div class="row">
          <div class="column">
            <div class="card"  >
              <h3 class="wh1"><a href="/register" ><font color="#e7f2fd">Annual</font></a></h3>
              <p class="wh"><a href="/register" ><font color="#FFFFFF">1 Year</font></p>
              <p class="wh"><a href="/register" ><font color="#FFFFFF">INR 500</font></p>
            </div>
          </div>
        
          <div class="column">
            <div class="card">
              <h3 class="wh1"><a href="/register" ><font color="#e7f2fd">Long Term</font></a></h3>
              <p class="wh"><a href="/register" ><font color="#FFFFFF">3 Years</font></a></p>
              <p class="wh"><a href="/register" ><font color="#FFFFFF">INR 1200</font></a></p>
            </div>
          </div>
          
          <div class="column">
            <div class="card">
              <h3 class="wh1"><a href="/register" ><font color="#e7f2fd">Overseas</font></a></h3>
              <p class="wh"><a href="/register" ><font color="#FFFFFF">1 Year</font></a></p>
              <p class="wh"><a href="/register" ><font color="#FFFFFF">USD 20(INR 1500)</font></a></p>
            </div>
          </div>
          
          
        </div>
        
                </div>
            </div>
        </div>
    </div>

    {{-- //Inst --}}
    <div class="breadcrumb-area">
            <div class="container h-100">
                <div class="row h-100 align-items-end">
                    <div class="col-12">        
            <h2 class="inv">
                    Institutional Membership Type</h2>&nbsp;&nbsp;&nbsp;&nbsp;
            
            <div class="row">
              <div class="column">
                <div class="card-one">
                  <h3 class="wh1" ><a href="/register" ><font color="#e7f2fd">Annual</font></a></h3>
                  <p class="wh"><a href="/register" ><font color="#FFFFFF">1 Year</font></a></p>
                  <p class="wh"><a href="/register" ><font color="#FFFFFF">INR 1000</font></a></p>
                </div>
              </div>
            
              <div class="column">
                <div class="card-one">
                  <h3 class="wh1"><a href="/register" ><font color="#e7f2fd">Long Term</font></a></h3>
                  <p class="wh"><a href="/register" ><font color="#FFFFFF">3 Years</font></a></p>
                  <p class="wh"><a href="/register" ><font color="#FFFFFF">INR 2500</font></a></p>
                </div>
              </div>
              
              <div class="column">
                <div class="card-one">
                  <h3 class="wh1"><a href="/register" ><font color="#e7f2fd">Overseas</font></a></h3>
                  <p class="wh"><a href="/register" ><font color="#FFFFFF">1 Year</font></a></p>
                  <p class="wh"><a href="/register" ><font color="#FFFFFF">USD 30(INR 2500)</font></a></p>
                </div>
              </div>
              
              
            </div>
            
                    </div>
                </div>
            </div>
        </div>
    
     <div class="breadcrumb-area">
            <div class="container h-100">
                <div class="row h-100 align-items-end">
                    <div class="col-12">  
		
            <a href="/register" class="button" style="background-color:#DF068C;color:white;">CLICK HERE to join AINET today!</a><br><br>
</div>
					</div>
</div>
</div>


    @endsection
